<?php
// This is a simple include file to maintain compatibility with the chat modules
// that are looking for db.php instead of database.php
require_once __DIR__ . '/database.php';
?> 