<?php
// This file displays the details of a site user
// It is included in site_users.php when action=view
// $user and $banInfo variables are passed from the parent file

// Helper function to format gender
function formatGender($genderId) {
    switch ($genderId) {
        case 1: return 'Erkek';
        case 2: return 'Kadın';
        case 3: return 'Beyan etmek istemiyorum';
        default: return 'Belirtilmemiş';
    }
}

// Format date for better readability
function formatDate($dateStr) {
    if (empty($dateStr)) return 'Belirtilmemiş';
    
    $date = new DateTime($dateStr);
    return $date->format('d.m.Y H:i');
}

// Format email verification status
$emailVerified = $user['email_verification'] ? 'Evet' : 'Hayır';

// Format 2FA status
$twoFactorStatus = $user['twofactor'] ? 'Aktif' : 'Pasif';

?>

<a href="site_users.php<?php echo isset($_GET['tab']) ? '?tab=' . $_GET['tab'] : ''; ?>" class="back-btn">
    <i class="bi bi-arrow-left"></i> Kullanıcı Listesine Dön
</a>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="bi bi-person-circle me-2"></i> 
                    <?php echo htmlspecialchars($user['username']); ?>
                    <?php if ($user['is_banned'] == 1): ?>
                        <span class="badge bg-danger ms-2">Banlı Kullanıcı</span>
                    <?php endif; ?>
                </h5>
                
                <div>
                    <?php if ($userCanEdit): // Only show if user has edit permission ?>
                        <?php if ($user['is_banned'] == 0): ?>
                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#banUserModal">
                            <i class="bi bi-shield-x"></i> Kullanıcıyı Banla
                        </button>
                        <?php else: ?>
                        <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#unbanUserModal">
                            <i class="bi bi-shield-check"></i> Banı Kaldır
                        </button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="detail-section">
                    <div class="detail-title"><i class="bi bi-person"></i> Kişisel Bilgiler</div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-row">
                                <div class="detail-label">Kullanıcı ID:</div>
                                <div class="detail-value"><?php echo $user['id']; ?></div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Kullanıcı Adı:</div>
                                <div class="detail-value"><?php echo htmlspecialchars($user['username']); ?></div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Ad:</div>
                                <div class="detail-value">
                                    <?php echo htmlspecialchars($user['firstName']); ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="firstName" data-value="<?php echo htmlspecialchars($user['firstName']); ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Soyad:</div>
                                <div class="detail-value">
                                    <?php echo htmlspecialchars($user['surname']); ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="surname" data-value="<?php echo htmlspecialchars($user['surname']); ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Cinsiyet:</div>
                                <div class="detail-value">
                                    <?php echo formatGender($user['gender']); ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="gender" data-value="<?php echo $user['gender']; ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Doğum Tarihi:</div>
                                <div class="detail-value">
                                    <?php 
                                    if (!empty($user['birthDay']) && !empty($user['birthMonth']) && !empty($user['birthYear'])) {
                                        echo $user['birthDay'] . '.' . $user['birthMonth'] . '.' . $user['birthYear'];
                                    } else {
                                        echo 'Belirtilmemiş';
                                    }
                                    ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="birth_date" 
                                       data-day="<?php echo $user['birthDay']; ?>" 
                                       data-month="<?php echo $user['birthMonth']; ?>" 
                                       data-year="<?php echo $user['birthYear']; ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-row">
                                <div class="detail-label">E-posta:</div>
                                <div class="detail-value">
                                    <?php echo htmlspecialchars($user['email']); ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="email" data-value="<?php echo htmlspecialchars($user['email']); ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Telefon:</div>
                                <div class="detail-value">
                                    <?php echo htmlspecialchars($user['phone']); ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="phone" data-value="<?php echo htmlspecialchars($user['phone']); ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Kimlik No:</div>
                                <div class="detail-value">
                                    <?php echo !empty($user['identity']) ? htmlspecialchars($user['identity']) : 'Belirtilmemiş'; ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="identity" data-value="<?php echo htmlspecialchars($user['identity'] ?? ''); ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Şehir:</div>
                                <div class="detail-value">
                                    <?php echo !empty($user['cityName']) ? htmlspecialchars($user['cityName']) : 'Belirtilmemiş'; ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="cityName" data-value="<?php echo htmlspecialchars($user['cityName'] ?? ''); ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Para Birimi:</div>
                                <div class="detail-value">TRY</div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Oluşturulma Tarihi:</div>
                                <div class="detail-value"><?php echo formatDate($user['createdAt']); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <div class="detail-title"><i class="bi bi-shield-lock"></i> Güvenlik Bilgileri</div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-row">
                                <div class="detail-label">E-posta Doğrulaması:</div>
                                <div class="detail-value">
                                    <?php if ($user['email_verification']): ?>
                                        <span class="badge bg-success">Doğrulanmış</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Doğrulanmamış</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">İki Faktörlü Kimlik Doğrulama:</div>
                                <div class="detail-value">
                                    <?php if ($user['twofactor']): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Pasif</span>
                                    <?php endif; ?>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="twofactor" data-value="<?php echo $user['twofactor']; ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if ($user['twofactor']): ?>
                            <div class="detail-row">
                                <div class="detail-label">2FA Secret Key:</div>
                                <div class="detail-value">
                                    <code><?php echo !empty($user['secret_key']) ? htmlspecialchars($user['secret_key']) : 'Belirtilmemiş'; ?></code>
                                    <?php if ($userCanEdit): ?>
                                    <a href="javascript:void(0)" class="edit-icon ms-2" data-field="secret_key" data-value="<?php echo htmlspecialchars($user['secret_key'] ?? ''); ?>">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-row">
                                <div class="detail-label">Hesap Durumu:</div>
                                <div class="detail-value">
                                    <?php if ($user['is_banned'] == 1): ?>
                                        <span class="badge bg-danger">Banlı</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Son Aktivite:</div>
                                <div class="detail-value"><?php echo !empty($user['last_activity']) ? formatDate($user['last_activity']) : 'Belirtilmemiş'; ?></div>
                            </div>
                            <?php if (!empty($user['referans_kodu'])): ?>
                            <div class="detail-row">
                                <div class="detail-label">Referans Kodu:</div>
                                <div class="detail-value"><?php echo htmlspecialchars($user['referans_kodu']); ?></div>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($user['kullanilan_referans_kodu'])): ?>
                            <div class="detail-row">
                                <div class="detail-label">Kullanılan Referans Kodu:</div>
                                <div class="detail-value"><?php echo htmlspecialchars($user['kullanilan_referans_kodu']); ?></div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <div class="detail-title"><i class="bi bi-cash-coin"></i> Bakiye Bilgileri</div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-row">
                                <div class="detail-label">Ana Bakiye:</div>
                                <div class="detail-value">
                                    <span class="fw-bold text-success"><?php echo number_format($user['ana_bakiye'], 2); ?> TRY</span>
                                </div>
                            </div>
                            <?php if (isset($user['spor_bonus'])): ?>
                            <div class="detail-row">
                                <div class="detail-label">Spor Bonus:</div>
                                <div class="detail-value">
                                    <?php echo !empty($user['spor_bonus']) ? number_format($user['spor_bonus'], 2) . ' TRY' : '0.00 TRY'; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if (isset($user['spor_freebet'])): ?>
                            <div class="detail-row">
                                <div class="detail-label">Spor Freebet:</div>
                                <div class="detail-value">
                                    <?php echo !empty($user['spor_freebet']) ? number_format($user['spor_freebet'], 2) . ' TRY' : '0.00 TRY'; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <?php if (isset($user['casino_bonus'])): ?>
                            <div class="detail-row">
                                <div class="detail-label">Casino Bonus:</div>
                                <div class="detail-value">
                                    <?php echo !empty($user['casino_bonus']) ? number_format($user['casino_bonus'], 2) . ' TRY' : '0.00 TRY'; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if (isset($user['klas_poker'])): ?>
                            <div class="detail-row">
                                <div class="detail-label">Klas Poker:</div>
                                <div class="detail-value">
                                    <?php echo !empty($user['klas_poker']) ? number_format($user['klas_poker'], 2) . ' TRY' : '0.00 TRY'; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if (isset($user['bonus_used'])): ?>
                            <div class="detail-row">
                                <div class="detail-label">Bonus Kullanımı:</div>
                                <div class="detail-value">
                                    <?php echo $user['bonus_used'] ? 'Evet' : 'Hayır'; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($user['address'])): ?>
                <div class="detail-section">
                    <div class="detail-title"><i class="bi bi-geo-alt"></i> Adres Bilgileri</div>
                    <div class="detail-row">
                        <div class="detail-label">Adres:</div>
                        <div class="detail-value"><?php echo nl2br(htmlspecialchars($user['address'])); ?></div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($user['is_banned'] == 1 && $banInfo): ?>
                <div class="detail-section" style="border-left-color: var(--red-500);">
                    <div class="detail-title"><i class="bi bi-exclamation-triangle text-danger"></i> Ban Bilgileri</div>
                    <div class="detail-row">
                        <div class="detail-label">Ban Sebebi:</div>
                        <div class="detail-value text-danger"><?php echo nl2br(htmlspecialchars($banInfo['ban_reason'])); ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Banlayan Admin:</div>
                        <div class="detail-value"><?php echo htmlspecialchars($banInfo['banned_by_username']); ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Ban Tarihi:</div>
                        <div class="detail-value"><?php echo formatDate($banInfo['banned_at']); ?></div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-tools"></i> Hızlı İşlemler</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <?php if ($userCanCreate): // Only show if user has create permission ?>
                    <button class="btn btn-outline-primary" type="button" data-bs-toggle="modal" data-bs-target="#sendEmailModal">
                        <i class="bi bi-envelope"></i> E-posta Gönder
                    </button>
                    <?php endif; ?>
                    
                    <?php if ($userCanEdit): // Only show if user has edit permission ?>
                        <?php if ($user['is_banned'] == 0): ?>
                        <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#banUserModal">
                            <i class="bi bi-shield-x"></i> Kullanıcıyı Banla
                        </button>
                        <?php else: ?>
                        <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#unbanUserModal">
                            <i class="bi bi-shield-check"></i> Banı Kaldır
                        </button>
                        <?php endif; ?>
                        
                        <button class="btn btn-outline-secondary" type="button" data-bs-toggle="modal" data-bs-target="#resetPasswordModal">
                            <i class="bi bi-key"></i> Şifre Sıfırla
                        </button>
                        
                        <div class="dropdown mt-2">
                            <button class="btn btn-outline-warning w-100 dropdown-toggle" type="button" id="balanceDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-cash-stack"></i> Bakiye İşlemleri
                            </button>
                            <ul class="dropdown-menu w-100" aria-labelledby="balanceDropdown">
                                <li>
                                    <button class="dropdown-item" type="button" data-bs-toggle="modal" data-bs-target="#editBalanceModal">
                                        <i class="bi bi-pencil-square me-2"></i> Bakiye Düzenle
                                    </button>
                                </li>
                                <li>
                                    <button class="dropdown-item" type="button" data-bs-toggle="modal" data-bs-target="#addBalanceModal">
                                        <i class="bi bi-plus-circle me-2 text-success"></i> Bakiye Ekle
                                    </button>
                                </li>
                                <li>
                                    <button class="dropdown-item" type="button" data-bs-toggle="modal" data-bs-target="#subtractBalanceModal">
                                        <i class="bi bi-dash-circle me-2 text-danger"></i> Bakiye Çıkar
                                    </button>
                                </li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Ban User Modal -->
<div class="modal fade" id="banUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Kullanıcıyı Banla</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <p class="text-danger">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong><?php echo htmlspecialchars($user['username']); ?></strong> kullanıcısını banlamak üzeresiniz.
                        Banlanan kullanıcı sisteme giriş yapamayacaktır.
                    </p>
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    <div class="mb-3">
                        <label for="banReason" class="form-label">Ban Sebebi:</label>
                        <textarea class="form-control" id="banReason" name="ban_reason" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="ban_user" class="btn btn-danger">Kullanıcıyı Banla</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Unban User Modal -->
<div class="modal fade" id="unbanUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Banı Kaldır</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <p class="text-success">
                        <i class="bi bi-check-circle me-2"></i>
                        <strong><?php echo htmlspecialchars($user['username']); ?></strong> kullanıcısının banını kaldırmak istediğinize emin misiniz?
                        Kullanıcı tekrar sisteme giriş yapabilecektir.
                    </p>
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="unban_user" class="btn btn-success">Banı Kaldır</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Şifre Sıfırla</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <p class="text-warning">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong><?php echo htmlspecialchars($user['username']); ?></strong> kullanıcısının şifresini sıfırlamak üzeresiniz.
                    </p>
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    <div class="mb-3">
                        <label for="newPassword" class="form-label">Yeni Şifre:</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="newPassword" name="new_password" required minlength="6">
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">Şifre en az 6 karakter uzunluğunda olmalıdır.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="reset_password" class="btn btn-warning">Şifreyi Sıfırla</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Balance Modal -->
<div class="modal fade" id="editBalanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Bakiye Düzenle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <p>
                        <strong><?php echo htmlspecialchars($user['username']); ?></strong> kullanıcısının bakiyesini düzenlemek üzeresiniz.
                    </p>
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    <div class="mb-3">
                        <label for="balanceType" class="form-label">Bakiye Türü:</label>
                        <select class="form-select" id="balanceType" name="balance_type" required>
                            <option value="ana_bakiye">Ana Bakiye (<?php echo number_format($user['ana_bakiye'], 2); ?> TRY)</option>
                            <?php if (isset($user['spor_bonus'])): ?>
                            <option value="spor_bonus">Spor Bonus (<?php echo number_format($user['spor_bonus'], 2); ?> TRY)</option>
                            <?php endif; ?>
                            <?php if (isset($user['casino_bonus'])): ?>
                            <option value="casino_bonus">Casino Bonus (<?php echo number_format($user['casino_bonus'], 2); ?> TRY)</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="newBalance" class="form-label">Yeni Bakiye (TRY):</label>
                        <input type="number" class="form-control" id="newBalance" name="new_balance" step="0.01" min="0" required
                               value="<?php echo number_format($user['ana_bakiye'], 2, '.', ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="balanceReason" class="form-label">Bakiye Değişikliği Sebebi:</label>
                        <textarea class="form-control" id="balanceReason" name="balance_reason" rows="2" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="update_balance" class="btn btn-primary">Bakiyeyi Güncelle</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Send Email Modal -->
<div class="modal fade" id="sendEmailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-envelope-paper me-2"></i>E-posta Gönder</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <div class="email-header p-3 mb-3 rounded" style="background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.2));">
                        <div class="d-flex align-items-center">
                            <div class="email-avatar me-3 rounded-circle bg-primary d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="bi bi-person-fill text-white fs-4"></i>
                            </div>
                            <div>
                                <h6 class="mb-1">Alıcı: <strong><?php echo htmlspecialchars($user['username']); ?></strong></h6>
                                <div class="text-muted small">E-posta: <span class="text-primary"><?php echo htmlspecialchars($user['email']); ?></span></div>
                            </div>
                        </div>
                    </div>
                    
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    
                    <div class="mb-3">
                        <label for="emailSubject" class="form-label fw-semibold">
                            <i class="bi bi-chat-square-text me-1"></i> E-posta Konusu:
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-primary bg-opacity-10 border-primary border-opacity-25">
                                <i class="bi bi-tag"></i>
                            </span>
                            <input type="text" class="form-control border-primary border-opacity-25" id="emailSubject" name="email_subject" required placeholder="Konu başlığı yazınız...">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="emailMessage" class="form-label fw-semibold">
                            <i class="bi bi-file-earmark-text me-1"></i> E-posta İçeriği:
                        </label>
                        <div class="email-toolbar mb-2 d-flex gap-1">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="formatText('bold')">
                                <i class="bi bi-type-bold"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="formatText('italic')">
                                <i class="bi bi-type-italic"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="formatText('underline')">
                                <i class="bi bi-type-underline"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="insertText('Merhaba,\n\nSitemizi tercih ettiğiniz için teşekkür ederiz.\n\nSaygılarımızla,\nSite Yönetimi')">
                                <i class="bi bi-file-earmark-text"></i> Şablon
                            </button>
                        </div>
                        <textarea class="form-control border-primary border-opacity-25" id="emailMessage" name="email_message" rows="8" required placeholder="Mesajınızı buraya yazın..."></textarea>
                        <div class="form-text mt-2">
                            <i class="bi bi-info-circle"></i> E-posta içeriğine otomatik olarak kullanıcı adı ve diğer bilgiler eklenecektir.
                        </div>
                    </div>
                    
                    <div class="email-preview mt-4 p-3 rounded border border-2 border-primary border-opacity-25" style="background-color: rgba(59, 130, 246, 0.05);">
                        <h6 class="border-bottom pb-2 mb-3"><i class="bi bi-eye me-2"></i>E-posta Önizleme</h6>
                        <div class="preview-container rounded bg-white p-3 shadow-sm" style="min-height: 100px;">
                            <div class="preview-header mb-3 pb-2 border-bottom">
                                <div><strong>Konu:</strong> <span id="previewSubject" class="text-primary">E-posta konusu burada görünecek</span></div>
                                <div><strong>Kimden:</strong> Site Yönetimi</div>
                                <div><strong>Kime:</strong> <?php echo htmlspecialchars($user['username']); ?> &lt;<?php echo htmlspecialchars($user['email']); ?>&gt;</div>
                            </div>
                            <div class="preview-body" id="previewBody">
                                <p>Sayın <strong><?php echo htmlspecialchars($user['username']); ?></strong>,</p>
                                <div id="previewContent" class="mb-3">E-posta içeriği burada görünecek...</div>
                                <p>Saygılarımızla,<br>Site Yönetimi</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i> İptal
                    </button>
                    <button type="submit" name="send_email" class="btn btn-primary">
                        <i class="bi bi-send me-1"></i> E-posta Gönder
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Balance Modal -->
<div class="modal fade" id="addBalanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle text-success me-2"></i>Bakiye Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <p>
                        <strong><?php echo htmlspecialchars($user['username']); ?></strong> kullanıcısının bakiyesine ekleme yapmak üzeresiniz.
                    </p>
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    <input type="hidden" name="operation" value="add">
                    
                    <div class="mb-3">
                        <label for="addBalanceType" class="form-label">Bakiye Türü:</label>
                        <select class="form-select" id="addBalanceType" name="balance_type" required>
                            <option value="ana_bakiye">Ana Bakiye (<?php echo number_format($user['ana_bakiye'], 2); ?> TRY)</option>
                            <?php if (isset($user['spor_bonus'])): ?>
                            <option value="spor_bonus">Spor Bonus (<?php echo number_format($user['spor_bonus'], 2); ?> TRY)</option>
                            <?php endif; ?>
                            <?php if (isset($user['casino_bonus'])): ?>
                            <option value="casino_bonus">Casino Bonus (<?php echo number_format($user['casino_bonus'], 2); ?> TRY)</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="addAmount" class="form-label">Eklenecek Tutar (TRY):</label>
                        <div class="input-group">
                            <span class="input-group-text bg-success text-white">
                                <i class="bi bi-plus-circle"></i>
                            </span>
                            <input type="number" class="form-control" id="addAmount" name="amount" step="0.01" min="0.01" required placeholder="Eklenecek miktar">
                            <span class="input-group-text">TRY</span>
                        </div>
                        <div class="form-text">Mevcut bakiyeye eklenecek tutarı giriniz.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="addBalanceReason" class="form-label">Bakiye Ekleme Sebebi:</label>
                        <textarea class="form-control" id="addBalanceReason" name="balance_reason" rows="2" required placeholder="Bonus ödülü, promosyon vs."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="add_balance" class="btn btn-success">
                        <i class="bi bi-plus-circle me-1"></i> Bakiye Ekle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Subtract Balance Modal -->
<div class="modal fade" id="subtractBalanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-dash-circle text-danger me-2"></i>Bakiye Çıkar</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <p class="text-danger">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong><?php echo htmlspecialchars($user['username']); ?></strong> kullanıcısının bakiyesinden çıkarma yapmak üzeresiniz.
                    </p>
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    <input type="hidden" name="operation" value="subtract">
                    
                    <div class="mb-3">
                        <label for="subtractBalanceType" class="form-label">Bakiye Türü:</label>
                        <select class="form-select" id="subtractBalanceType" name="balance_type" required>
                            <option value="ana_bakiye">Ana Bakiye (<?php echo number_format($user['ana_bakiye'], 2); ?> TRY)</option>
                            <?php if (isset($user['spor_bonus'])): ?>
                            <option value="spor_bonus">Spor Bonus (<?php echo number_format($user['spor_bonus'], 2); ?> TRY)</option>
                            <?php endif; ?>
                            <?php if (isset($user['casino_bonus'])): ?>
                            <option value="casino_bonus">Casino Bonus (<?php echo number_format($user['casino_bonus'], 2); ?> TRY)</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="subtractAmount" class="form-label">Çıkarılacak Tutar (TRY):</label>
                        <div class="input-group">
                            <span class="input-group-text bg-danger text-white">
                                <i class="bi bi-dash-circle"></i>
                            </span>
                            <input type="number" class="form-control" id="subtractAmount" name="amount" step="0.01" min="0.01" required placeholder="Çıkarılacak miktar">
                            <span class="input-group-text">TRY</span>
                        </div>
                        <div class="form-text" id="maxSubtractHint">Mevcut bakiyeden düşülecek tutarı giriniz.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="subtractBalanceReason" class="form-label">Bakiye Çıkarma Sebebi:</label>
                        <textarea class="form-control" id="subtractBalanceReason" name="balance_reason" rows="2" required placeholder="Ceza, iptal vs."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="subtract_balance" class="btn btn-danger">
                        <i class="bi bi-dash-circle me-1"></i> Bakiye Çıkar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
/* Modal fix to prevent stacking and backdrop issues */
.modal {
    z-index: 1050;
}

.modal-backdrop {
    z-index: 1040;
}

/* Center modals vertically and horizontally */
.modal-dialog {
    display: flex !important;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    min-height: calc(100vh - 60px);
    padding: 30px;
}

.modal-content {
    width: 100%;
    max-width: 100%;
    box-shadow: 0 5px 25px rgba(0, 0, 0, 0.2);
    border: none;
    border-radius: 8px;
}

/* Ensure modals are vertically centered */
.modal-open .modal {
    display: flex !important;
    align-items: center;
    justify-content: center;
    padding-right: 0 !important;
}

/* Prevent multiple backdrop stacking */
body {
    overflow: auto !important;
    padding-right: 0 !important;
}

/* Enhance modal animations */
.modal.fade .modal-dialog {
    transition: transform 0.3s ease-out, opacity 0.3s ease;
    transform: translateY(-30px);
    opacity: 0;
}

.modal.show .modal-dialog {
    transform: translateY(0);
    opacity: 1;
}

/* Adjust header and footer styling for better appearance */
.modal-header {
    border-bottom: 1px solid rgba(71, 85, 105, 0.2);
    background: linear-gradient(145deg, rgba(15, 23, 42, 0.5), rgba(30, 41, 59, 0.7));
    border-radius: 8px 8px 0 0;
    padding: 1rem 1.5rem;
}

.modal-footer {
    border-top: 1px solid rgba(71, 85, 105, 0.2);
    background: linear-gradient(145deg, rgba(15, 23, 42, 0.3), rgba(30, 41, 59, 0.5));
    border-radius: 0 0 8px 8px;
    padding: 1rem 1.5rem;
}

/* Improved button styling */
.modal .btn {
    border-radius: 6px;
    font-weight: 600;
    padding: 0.5rem 1.25rem;
    transition: all 0.3s ease;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.modal .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

/* Fix autofocus issues */
.modal input:focus,
.modal textarea:focus,
.modal select:focus {
    box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25) !important;
}

/* Custom scrollbar for long content */
.modal-body {
    max-height: calc(100vh - 200px);
    overflow-y: auto;
    padding: 1.5rem;
}

.modal-body::-webkit-scrollbar {
    width: 6px;
}

.modal-body::-webkit-scrollbar-track {
    background: rgba(15, 23, 42, 0.1);
}

.modal-body::-webkit-scrollbar-thumb {
    background: rgba(59, 130, 246, 0.5);
    border-radius: 3px;
}

.modal-body::-webkit-scrollbar-thumb:hover {
    background: rgba(59, 130, 246, 0.8);
}

/* Style form help text to be more visible with blue/white colors */
.form-text {
    color: rgba(255, 255, 255, 0.9) !important;
    font-weight: 500;
    font-size: 0.85rem;
    margin-top: 0.5rem;
    padding-left: 0.5rem;
    border-left: 2px solid rgba(59, 130, 246, 0.7);
    transition: all 0.2s ease;
}

.form-text:hover {
    border-left-color: rgba(96, 165, 250, 1);
    color: #ffffff !important;
    background-color: rgba(59, 130, 246, 0.1);
    border-radius: 0 4px 4px 0;
    padding: 0.3rem 0.5rem;
}

/* Add subtle blue highlight for other hint texts */
.text-muted, .form-text {
    color: rgba(191, 219, 254, 0.9) !important;
}

/* Max amount text specific styling */
#maxSubtractHint {
    color: rgba(219, 234, 254, 1) !important;
    background-color: rgba(59, 130, 246, 0.1);
    padding: 0.4rem 0.7rem;
    border-radius: 6px;
    border-left: 3px solid #3b82f6;
}

#maxSubtractHint strong {
    color: #ffffff;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle password visibility
    const togglePassword = document.getElementById('togglePassword');
    const password = document.getElementById('newPassword');
    
    if (togglePassword && password) {
        togglePassword.addEventListener('click', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.querySelector('i').classList.toggle('bi-eye');
            this.querySelector('i').classList.toggle('bi-eye-slash');
        });
    }
    
    // Update balance field when type changes
    const balanceType = document.getElementById('balanceType');
    const newBalance = document.getElementById('newBalance');
    
    if (balanceType && newBalance) {
        balanceType.addEventListener('change', function() {
            const selectedType = this.value;
            let currentValue = 0;
            
            // Set current value based on selected type
            <?php if (isset($user['ana_bakiye'])): ?>
            if (selectedType === 'ana_bakiye') {
                currentValue = <?php echo number_format($user['ana_bakiye'], 2, '.', ''); ?>;
            }
            <?php endif; ?>
            
            <?php if (isset($user['spor_bonus'])): ?>
            if (selectedType === 'spor_bonus') {
                currentValue = <?php echo number_format($user['spor_bonus'], 2, '.', ''); ?>;
            }
            <?php endif; ?>
            
            <?php if (isset($user['casino_bonus'])): ?>
            if (selectedType === 'casino_bonus') {
                currentValue = <?php echo number_format($user['casino_bonus'], 2, '.', ''); ?>;
            }
            <?php endif; ?>
            
            newBalance.value = currentValue;
        });
    }
    
    // Fix modal backdrop issues
    function removeBackdrops() {
        const extraBackdrops = document.querySelectorAll('.modal-backdrop:not(:first-child)');
        extraBackdrops.forEach(backdrop => {
            backdrop.parentNode.removeChild(backdrop);
        });
        
        const body = document.body;
        body.classList.remove('modal-open');
        body.style.overflow = '';
        body.style.paddingRight = '';
    }
    
    // Clean up any stray backdrops on page load
    window.addEventListener('load', function() {
        removeBackdrops();
        
        // If there's a hash in the URL, handle it (for modal focus)
        if(window.location.hash) {
            const modalId = window.location.hash;
            const modal = document.querySelector(modalId);
            if(modal) {
                const modalInstance = new bootstrap.Modal(modal);
                setTimeout(() => {
                    modalInstance.show();
                }, 500);
            }
        }
    });
    
    // Make sure modals are properly destroyed when hidden
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.addEventListener('shown.bs.modal', function() {
            // Focus on first input when modal opens
            const firstInput = this.querySelector('input, textarea, select');
            if(firstInput) {
                setTimeout(() => {
                    firstInput.focus();
                }, 100);
            }
        });
        
        modal.addEventListener('hidden.bs.modal', function() {
            removeBackdrops();
            
            // Force cleanup after modal is hidden
            setTimeout(() => {
                if(document.querySelectorAll('.modal-backdrop').length > 0) {
                    document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
                        backdrop.parentNode.removeChild(backdrop);
                    });
                }
                
                // Reset overflow
                document.body.style.overflow = '';
                document.body.style.paddingRight = '';
            }, 100);
        });
    });
    
    // Ensure modal buttons work properly
    document.querySelectorAll('[data-bs-toggle="modal"]').forEach(button => {
        button.addEventListener('click', function(e) {
            // Prevent default if it's a link
            if(this.tagName === 'A') {
                e.preventDefault();
            }
            
            // Remove any stray backdrops before showing new modal
            removeBackdrops();
            
            // Close any open modals before opening a new one
            modals.forEach(modal => {
                const instance = bootstrap.Modal.getInstance(modal);
                if(instance) {
                    instance.hide();
                }
            });
            
            // Get the target modal
            const modalId = this.getAttribute('data-bs-target');
            const modal = document.querySelector(modalId);
            
            // Focus modal content after it's shown
            if(modal) {
                modal.addEventListener('shown.bs.modal', function() {
                    const focusEl = modal.querySelector('textarea, input, select');
                    if(focusEl) {
                        focusEl.focus();
                    }
                }, { once: true });
            }
        });
    });
    
    // Handle form submission properly
    document.querySelectorAll('.modal form').forEach(form => {
        form.addEventListener('submit', function() {
            const modal = this.closest('.modal');
            if(modal) {
                const modalInstance = bootstrap.Modal.getInstance(modal);
                if(modalInstance) {
                    // Hide modal before submitting to prevent backdrop issues
                    modalInstance.hide();
                    
                    // Allow time for modal to hide before submission
                    setTimeout(() => {
                        removeBackdrops();
                    }, 300);
                }
            }
        });
    });

    // Add these functions for the email formatting tools
    function formatText(format) {
        const textarea = document.getElementById('emailMessage');
        if (!textarea) return;
        
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selectedText = textarea.value.substring(start, end);
        let formattedText = '';
        
        switch(format) {
            case 'bold':
                formattedText = `**${selectedText}**`;
                break;
            case 'italic':
                formattedText = `*${selectedText}*`;
                break;
            case 'underline':
                formattedText = `_${selectedText}_`;
                break;
            default:
                formattedText = selectedText;
        }
        
        textarea.value = textarea.value.substring(0, start) + formattedText + textarea.value.substring(end);
        textarea.focus();
        textarea.selectionStart = start + formattedText.length;
        textarea.selectionEnd = start + formattedText.length;
        
        updatePreview();
    }

    function insertText(text) {
        const textarea = document.getElementById('emailMessage');
        if (!textarea) return;
        
        textarea.value = text;
        textarea.focus();
        
        updatePreview();
    }

    function updatePreview() {
        const subject = document.getElementById('emailSubject').value || 'E-posta konusu burada görünecek';
        const message = document.getElementById('emailMessage').value || 'E-posta içeriği burada görünecek...';
        
        document.getElementById('previewSubject').textContent = subject;
        
        // Format the message with simple markdown-like syntax
        let formattedMessage = message
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/_(.*?)_/g, '<u>$1</u>')
            .replace(/\n/g, '<br>');
        
        document.getElementById('previewContent').innerHTML = formattedMessage;
    }

    // Email preview functionality
    const emailSubject = document.getElementById('emailSubject');
    const emailMessage = document.getElementById('emailMessage');
    
    if (emailSubject && emailMessage) {
        emailSubject.addEventListener('input', updatePreview);
        emailMessage.addEventListener('input', updatePreview);
        
        // Initialize preview on modal show
        document.getElementById('sendEmailModal').addEventListener('shown.bs.modal', function () {
            updatePreview();
            emailSubject.focus();
        });
    }

    // Balance type selectors
    const balanceTypeSelectors = {
        add: document.getElementById('addBalanceType'),
        subtract: document.getElementById('subtractBalanceType')
    };
    
    // Amount inputs
    const amountInputs = {
        subtract: document.getElementById('subtractAmount')
    };
    
    // Max subtract hint
    const maxSubtractHint = document.getElementById('maxSubtractHint');
    
    // Current balances
    const balances = {
        ana_bakiye: <?php echo number_format($user['ana_bakiye'], 2, '.', ''); ?>,
        <?php if (isset($user['spor_bonus'])): ?>
        spor_bonus: <?php echo number_format($user['spor_bonus'], 2, '.', ''); ?>,
        <?php endif; ?>
        <?php if (isset($user['casino_bonus'])): ?>
        casino_bonus: <?php echo number_format($user['casino_bonus'], 2, '.', ''); ?>,
        <?php endif; ?>
    };
    
    // Update max amount for subtract
    function updateMaxAmount() {
        if (balanceTypeSelectors.subtract && amountInputs.subtract) {
            const selectedType = balanceTypeSelectors.subtract.value;
            const currentBalance = balances[selectedType] || 0;
            
            amountInputs.subtract.max = currentBalance;
            maxSubtractHint.innerHTML = `Mevcut bakiyeden düşülecek tutarı giriniz. <strong>Maksimum: ${currentBalance} TRY</strong>`;
            
            // Validate current input
            if (parseFloat(amountInputs.subtract.value) > currentBalance) {
                amountInputs.subtract.value = currentBalance;
            }
        }
    }
    
    // Add event listeners
    if (balanceTypeSelectors.subtract) {
        balanceTypeSelectors.subtract.addEventListener('change', updateMaxAmount);
    }
    
    if (amountInputs.subtract) {
        amountInputs.subtract.addEventListener('input', function() {
            const selectedType = balanceTypeSelectors.subtract.value;
            const currentBalance = balances[selectedType] || 0;
            
            if (parseFloat(this.value) > currentBalance) {
                this.value = currentBalance;
            }
        });
    }
    
    // Initialize
    if (balanceTypeSelectors.subtract) {
        updateMaxAmount();
    }
    
    // Modal shown events
    const subtractBalanceModal = document.getElementById('subtractBalanceModal');
    if (subtractBalanceModal) {
        subtractBalanceModal.addEventListener('shown.bs.modal', function() {
            updateMaxAmount();
            if (amountInputs.subtract) {
                amountInputs.subtract.focus();
            }
        });
    }
});
</script>

<?php if ($userCanEdit): ?>
<!-- SweetAlert2 CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
<!-- SweetAlert2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>

<script>
$(document).ready(function() {
    // Handle edit icon click
    $('.edit-icon').on('click', function() {
        const field = $(this).data('field');
        const userId = <?php echo $user['id']; ?>;
        
        if (field === 'gender') {
            const currentValue = $(this).data('value');
            
            Swal.fire({
                title: 'Cinsiyet Düzenle',
                html: `
                    <select id="gender-select" class="form-control">
                        <option value="0" ${currentValue == 0 ? 'selected' : ''}>Belirtilmemiş</option>
                        <option value="1" ${currentValue == 1 ? 'selected' : ''}>Erkek</option>
                        <option value="2" ${currentValue == 2 ? 'selected' : ''}>Kadın</option>
                        <option value="3" ${currentValue == 3 ? 'selected' : ''}>Beyan etmek istemiyorum</option>
                    </select>
                `,
                showCancelButton: true,
                confirmButtonText: 'Güncelle',
                cancelButtonText: 'İptal',
                focusConfirm: false,
                preConfirm: () => {
                    return document.getElementById('gender-select').value;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    updateUserField(userId, field, result.value);
                }
            });
        } else if (field === 'birth_date') {
            const day = $(this).data('day') || '';
            const month = $(this).data('month') || '';
            const year = $(this).data('year') || '';
            
            Swal.fire({
                title: 'Doğum Tarihi Düzenle',
                html: `
                    <div class="row">
                        <div class="col-md-4">
                            <label for="birth-day">Gün</label>
                            <input type="number" id="birth-day" class="form-control" min="1" max="31" value="${day}">
                        </div>
                        <div class="col-md-4">
                            <label for="birth-month">Ay</label>
                            <input type="number" id="birth-month" class="form-control" min="1" max="12" value="${month}">
                        </div>
                        <div class="col-md-4">
                            <label for="birth-year">Yıl</label>
                            <input type="number" id="birth-year" class="form-control" min="1900" max="${new Date().getFullYear()}" value="${year}">
                        </div>
                    </div>
                `,
                showCancelButton: true,
                confirmButtonText: 'Güncelle',
                cancelButtonText: 'İptal',
                focusConfirm: false,
                preConfirm: () => {
                    const newDay = document.getElementById('birth-day').value;
                    const newMonth = document.getElementById('birth-month').value;
                    const newYear = document.getElementById('birth-year').value;
                    
                    if (newDay && (newDay < 1 || newDay > 31)) {
                        Swal.showValidationMessage('Geçersiz gün değeri (1-31)');
                        return false;
                    }
                    
                    if (newMonth && (newMonth < 1 || newMonth > 12)) {
                        Swal.showValidationMessage('Geçersiz ay değeri (1-12)');
                        return false;
                    }
                    
                    if (newYear && (newYear < 1900 || newYear > new Date().getFullYear())) {
                        Swal.showValidationMessage(`Geçersiz yıl değeri (1900-${new Date().getFullYear()})`);
                        return false;
                    }
                    
                    return { day: newDay, month: newMonth, year: newYear };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    updateUserField(userId, 'birthDay', result.value.day);
                    updateUserField(userId, 'birthMonth', result.value.month);
                    updateUserField(userId, 'birthYear', result.value.year);
                }
            });
        } else if (field === 'twofactor') {
            const currentValue = $(this).data('value');
            const newValue = currentValue == 1 ? 0 : 1;
            const statusText = newValue == 1 ? 'Aktif' : 'Pasif';
            
            Swal.fire({
                title: 'İki Faktörlü Kimlik Doğrulama',
                text: `İki faktörlü kimlik doğrulamayı ${statusText} olarak ayarlamak istediğinizden emin misiniz?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Evet, Güncelle',
                cancelButtonText: 'İptal'
            }).then((result) => {
                if (result.isConfirmed) {
                    updateUserField(userId, field, newValue);
                }
            });
        } else {
            const currentValue = $(this).data('value') || '';
            const fieldTitle = getFieldTitle(field);
            
            Swal.fire({
                title: `${fieldTitle} Düzenle`,
                input: 'text',
                inputValue: currentValue,
                showCancelButton: true,
                confirmButtonText: 'Güncelle',
                cancelButtonText: 'İptal',
                inputValidator: (value) => {
                    // Input validation
                    if (field === 'email' && value && !validateEmail(value)) {
                        return 'Geçerli bir e-posta adresi giriniz';
                    }
                    
                    if (field === 'phone' && value && !validatePhone(value)) {
                        return 'Geçerli bir telefon numarası giriniz (10-11 rakam)';
                    }
                    
                    if (field === 'identity' && value && !validateIdentity(value)) {
                        return 'Geçerli bir kimlik numarası giriniz (11 rakam)';
                    }
                    
                    return null;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    updateUserField(userId, field, result.value);
                }
            });
        }
    });
    
    // Helper function to update user field via AJAX
    function updateUserField(userId, field, value) {
        $.ajax({
            url: 'ajax/update_user_info.php',
            type: 'POST',
            data: {
                user_id: userId,
                field: field,
                value: value
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Başarılı!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        // Reload the page to reflect changes
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata!',
                        text: response.message || 'Bir hata oluştu. Lütfen tekrar deneyin.'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Hata!',
                    text: 'Sunucu ile iletişim kurulamadı. Lütfen tekrar deneyin.'
                });
            }
        });
    }
    
    // Helper function to get field title
    function getFieldTitle(field) {
        const titles = {
            'firstName': 'Ad',
            'surname': 'Soyad',
            'email': 'E-posta',
            'phone': 'Telefon',
            'identity': 'Kimlik No',
            'cityName': 'Şehir',
            'secret_key': '2FA Secret Key'
        };
        
        return titles[field] || field;
    }
    
    // Validation functions
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function validatePhone(phone) {
        return phone.match(/^[0-9]{10,11}$/);
    }
    
    function validateIdentity(identity) {
        return identity.match(/^[0-9]{11}$/);
    }
});
</script>
<?php endif; ?> 