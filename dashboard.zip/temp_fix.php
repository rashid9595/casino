<?php $pageContent = $content; ?>
